# OpenLab-AVR-ATMEGA32-SD-Card-examples
SD Card Read &amp; Write example for AVR-ATMEGA32APU1533.
