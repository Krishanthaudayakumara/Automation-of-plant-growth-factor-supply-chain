/*
 * SD card.c
 *
 * Created: 5/10/2016 11:50:27 AM
 * Author : user
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

