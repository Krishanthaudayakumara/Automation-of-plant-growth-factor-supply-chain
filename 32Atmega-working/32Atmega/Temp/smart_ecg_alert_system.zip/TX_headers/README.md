user defined headers for Transmitter
