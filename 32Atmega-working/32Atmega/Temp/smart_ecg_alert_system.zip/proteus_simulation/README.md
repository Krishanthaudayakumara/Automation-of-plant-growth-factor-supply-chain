# simulation



For using the GSM library of proteus extract the rar file then copy and paste the extracted files in proteus library folder available in your PC's c drive example- for me the loaction was     C:\Program Files (x86)\Labcenter Electronics\Proteus 8 Professional\LIBRARY

Now in the provided proteus proteus project, upload extracted hex file of the gsm mosule to the gsm module in the project.


# Setting up the simulator-

upload the transmitter hex file on the ATmega 16 of the transmitter
upload the receiver hex file on the ATmega 16 of the receiver



# The Heart Rate Sensor-
Circuit diagram of the heart beat sensor has also been provided for referrence
In the main simulation of the project the LOGIC TOGGLE works as the heart beat sensor
